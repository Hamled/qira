#!/usr/bin/env ruby

changelist_re = /^set changelist \d+ at (\h{16})/
addr_re = /#{ARGV[1]}/
in_proc_changelist = false

File.foreach(ARGV[0]) do |line|
  m = line.match(changelist_re)
  in_proc_changelist = (m[1] =~ addr_re) if m

  puts line if in_proc_changelist
end
